package com.mentor.myapplicationfirst

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.layout)

        val addButton: Button = findViewById(R.id.Addbutton);
        val firstNumEditText: EditText = findViewById(R.id.firstNumEditText)
        val secondNumEditText: EditText = findViewById(R.id.editTextText4)
        val resultTextView: TextView = findViewById(R.id.textView2)

        addButton.setOnClickListener {
            val num1 = firstNumEditText.text.toString().toInt()
            val num2 = secondNumEditText.text.toString().toInt()
            val result = num1 + num2
            resultTextView.text = result.toString()
        }
    };
}


