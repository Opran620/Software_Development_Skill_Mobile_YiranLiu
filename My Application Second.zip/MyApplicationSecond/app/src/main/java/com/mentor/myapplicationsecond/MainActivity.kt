package com.mentor.myapplicationsecond

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.layout)

        val buttonFirst: Button = findViewById(R.id.Firstbutton)
        buttonFirst.setOnClickListener {
            val startIntent = Intent(this, SecondActivity::class.java)
            startActivity(startIntent)
        }

        val buttonGoogle: Button = findViewById(R.id.Secondbutton)
        buttonGoogle.setOnClickListener {
            val googleUrl = "https://www.yahoo.com"
            val webAddress: Uri = Uri.parse(googleUrl)

            val gotoGoogle = Intent(Intent.ACTION_VIEW, webAddress)

            if (gotoGoogle.resolveActivity(packageManager) != null) {
                startActivity(gotoGoogle)
            }
        }


    };
}


