package com.mentor.myapplicationthird

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.ImageView
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge

class DetailActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.detail_activity)

        // 获取 Intent 并读取传递的索引
        val index = intent.getIntExtra("butterfield.mentorschools.org.ITEM_INDEX", -1)

        if (index > -1) {
            val pic = getImg(index)
            val img: ImageView = findViewById(R.id.imageView)
            scaleImg(img, pic)
        }
    }

    // 根据索引返回对应的图片资源 ID
    private fun getImg(index: Int): Int {
        return when (index) {
            0 -> R.drawable.peach
            1 -> R.drawable.tomato
            2 -> R.drawable.squash
            else -> -1
        }
    }

    // 缩放图片以适应屏幕宽度
    private fun scaleImg(img: ImageView, pic: Int) {
        val screenWidth = windowManager.defaultDisplay.width

        val options = BitmapFactory.Options()
        options.inJustDecodeBounds = true
        BitmapFactory.decodeResource(resources, pic, options)

        val imgWidth = options.outWidth

        if (imgWidth > screenWidth) {
            val ratio = Math.round(imgWidth.toFloat() / screenWidth.toFloat())
            options.inSampleSize = ratio
        }

        options.inJustDecodeBounds = false
        val scaledImg: Bitmap = BitmapFactory.decodeResource(resources, pic, options)
        img.setImageBitmap(scaledImg)
    }
}
