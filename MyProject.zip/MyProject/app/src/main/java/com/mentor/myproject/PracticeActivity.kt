package com.mentor.myproject

import android.os.Bundle
import android.os.SystemClock
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.roundToInt

/**
 * PracticeActivity
 * - Displays the sheet music for a selected piano piece
 * - Tracks practice time using a timer
 * - Allows starting and stopping practice sessions
 */
class PracticeActivity : AppCompatActivity() {

    // Variables for tracking practice time
    private var startTime: Long = 0L
    private var running = false

    // Name of the piece to practice
    private var pieceName: String = "twinkle"

    // UI elements
    private lateinit var imgScore: ImageView
    private lateinit var tvTimer: TextView
    private lateinit var btnBack: Button
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_practice)

        // Bind views manually (no ViewBinding)
        imgScore = findViewById(R.id.imgScore)
        tvTimer = findViewById(R.id.tvTimer)
        btnBack = findViewById(R.id.btnBack)
        btnStart = findViewById(R.id.btnStartPractice)
        btnStop = findViewById(R.id.btnStopPractice)

        // Get the piece name passed via Intent or use default "twinkle"
        pieceName = intent.getStringExtra("pieceName") ?: "twinkle"

        // Update the sheet music image
        updateScoreImage()

        // Back button: finish activity
        btnBack.setOnClickListener { finish() }

        // Start button: start timer
        btnStart.setOnClickListener { startPractice() }

        // Stop button: stop timer and show elapsed time
        btnStop.setOnClickListener { stopPractice() }
    }

    /**
     * Starts the practice timer
     */
    private fun startPractice() {
        if (!running) {
            startTime = SystemClock.elapsedRealtime()
            running = true
            btnStart.isEnabled = false
            btnStop.isEnabled = true
            tvTimer.post(updateTimer)
        }
    }

    /**
     * Stops the practice timer and shows a Toast with elapsed minutes
     */
    private fun stopPractice() {
        if (running) {
            running = false
            val elapsed = SystemClock.elapsedRealtime() - startTime
            val minutes = (elapsed / 60000.0).roundToInt()
            Toast.makeText(this, "Saved $minutes min practice", Toast.LENGTH_SHORT).show()
            btnStart.isEnabled = true
            btnStop.isEnabled = false
        }
    }

    /**
     * Runnable to update the timer TextView every second
     */
    private val updateTimer = object : Runnable {
        override fun run() {
            if (running) {
                val elapsed = SystemClock.elapsedRealtime() - startTime
                val min = (elapsed / 60000).toInt()
                val sec = (elapsed / 1000 % 60).toInt()
                tvTimer.text = String.format("%02d:%02d", min, sec)
                tvTimer.postDelayed(this, 1000)
            }
        }
    }

    /**
     * Update the ImageView to display the sheet music of the selected piece
     * Falls back to a default icon if the resource is missing
     */
    private fun updateScoreImage() {
        // Resource names should match drawable file names in lowercase
        val resId = resources.getIdentifier(pieceName.lowercase(), "drawable", packageName)
        if (resId != 0) {
            imgScore.setImageResource(resId)

            // OPTIONAL: Make the image scale to fit the screen better
            imgScore.adjustViewBounds = true
            imgScore.scaleType = ImageView.ScaleType.FIT_CENTER

        } else {
            imgScore.setImageResource(android.R.drawable.ic_menu_gallery)
            Toast.makeText(this, "Resource not found for $pieceName", Toast.LENGTH_SHORT).show()
        }
    }
}
