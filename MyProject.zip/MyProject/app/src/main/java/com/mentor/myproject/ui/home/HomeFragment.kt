package com.mentor.myproject.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.mentor.myproject.PracticeActivity
import com.mentor.myproject.RecentActivity
import com.mentor.myproject.AddPieceActivity
import com.mentor.myproject.StatsActivity
import com.mentor.myproject.VirtualPianoActivity
import com.mentor.myproject.MetronomeActivity
import com.mentor.myproject.databinding.FragmentHomeBinding
import java.text.SimpleDateFormat
import java.util.*

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root

        // 设置顶部日期/时间
        updateDateTime()

        // -----------------------
        // 功能按钮点击事件
        // -----------------------
        binding.btnPractice.setOnClickListener {
            startActivity(Intent(requireContext(), PracticeActivity::class.java))
        }

        binding.btnVirtualPiano.setOnClickListener {
            startActivity(Intent(requireContext(), VirtualPianoActivity::class.java))
        }

        binding.btnMetronome.setOnClickListener {
            startActivity(Intent(requireContext(), MetronomeActivity::class.java))
        }

        binding.btnFingerTutorial.setOnClickListener {
            // 这里示例跳转到 YouTube 网页
            val url = "https://www.youtube.com/results?search_query=piano+finger+tutorial"
            startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)))
        }

        binding.btnExit.setOnClickListener {
            requireActivity().finishAffinity() // 退出整个应用
        }

        return root
    }

    private fun updateDateTime() {
        val sdf = SimpleDateFormat("yyyy-MM-dd, EEEE HH:mm", Locale.getDefault())
        binding.tvDateTime.text = sdf.format(Date())
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
