package com.mentor.myproject

import android.media.MediaPlayer
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mentor.myproject.databinding.ActivityVirtualPianoBinding

/**
 * VirtualPianoActivity
 * - Simulates a simple piano with 7 keys (C to B)
 * - Plays corresponding note sound when a button is pressed
 */
class VirtualPianoActivity : AppCompatActivity() {

    // ViewBinding instance to access layout views
    private lateinit var binding: ActivityVirtualPianoBinding

    // Map each piano button ID to the corresponding raw audio resource
    private val keyMap = mapOf(
        R.id.btnC to R.raw.c4,
        R.id.btnD to R.raw.d4,
        R.id.btnE to R.raw.e4,
        R.id.btnF to R.raw.f4,
        R.id.btnG to R.raw.g4,
        R.id.btnA to R.raw.a4,
        R.id.btnB to R.raw.b4
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inflate layout using ViewBinding
        binding = ActivityVirtualPianoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // ----------------------
        // Set up piano key buttons
        // ----------------------
        for ((btnId, resId) in keyMap) {
            // Find the button by ID
            findViewById<android.widget.Button>(btnId).setOnClickListener {
                // Create a MediaPlayer instance for the note
                val mp = MediaPlayer.create(this, resId)
                mp.start() // Play the note

                // Release MediaPlayer resources when the note finishes
                mp.setOnCompletionListener { it.release() }
            }
        }

        // ----------------------
        // Back button
        // ----------------------
        // Returns to previous screen
        binding.btnBack.setOnClickListener { finish() }
    }
}
