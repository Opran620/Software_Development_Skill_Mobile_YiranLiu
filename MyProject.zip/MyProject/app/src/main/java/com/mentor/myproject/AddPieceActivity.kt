package com.mentor.myproject

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class AddPieceActivity : AppCompatActivity() {

    private val pieceList = mutableListOf("twinkle","happy_birthday","jingle_bells","scarborough","castle")
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_piece)

        val editSearch = findViewById<EditText>(R.id.editSearch)
        val listView = findViewById<ListView>(R.id.listViewPieces)
        val btnBack = findViewById<Button>(R.id.btnBack)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, pieceList)
        listView.adapter = adapter

        // 搜索过滤
        editSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val filtered = pieceList.filter { it.contains(s.toString(), ignoreCase = true) }.sorted()
                adapter.clear()
                adapter.addAll(filtered)
                adapter.notifyDataSetChanged()
            }
        })

        // 点击选择曲目
        listView.setOnItemClickListener { _, _, position, _ ->
            val pieceName = adapter.getItem(position)
            if (pieceName.isNullOrEmpty()) {
                Toast.makeText(this, "Invalid selection", Toast.LENGTH_SHORT).show()
                return@setOnItemClickListener
            }

            val intent = Intent(this, PracticeActivity::class.java)
            intent.putExtra("pieceName", pieceName.lowercase())
            startActivity(intent)
        }

        // 返回菜单
        btnBack.setOnClickListener { finish() }
    }
}
