package com.mentor.myproject

import android.media.MediaPlayer
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.mentor.myproject.databinding.ActivityMetronomeBinding

/**
 * Metronome Activity
 * - Allows the user to select a time signature (4/4, 3/4, 2/4)
 * - Play a looping click sound
 * - Switch tempo using "Next" button
 */
class MetronomeActivity : AppCompatActivity() {

    // ViewBinding object to access layout elements
    private lateinit var binding: ActivityMetronomeBinding

    // List of supported time signatures
    private val tempos = listOf("4/4", "3/4", "2/4")

    // Currently selected tempo index
    private var currentTempoIndex = 0

    // Whether metronome is playing
    private var isPlaying = false

    // MediaPlayer instance for playing the click sound
    private var mediaPlayer: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inflate layout using ViewBinding
        binding = ActivityMetronomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Display time signatures in a ListView
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, tempos)
        binding.listViewTempos.adapter = adapter

        // Back button: close the activity
        binding.btnBack.setOnClickListener { finish() }

        // Play button: start looping the click sound
        binding.btnPlay.setOnClickListener {
            if (!isPlaying) {
                playBeat()
                isPlaying = true
            }
        }

        // Stop button: stop and release MediaPlayer
        binding.btnStop.setOnClickListener {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
            isPlaying = false
        }

        // Next button: change to the next time signature
        binding.btnNext.setOnClickListener {
            currentTempoIndex = (currentTempoIndex + 1) % tempos.size
            Toast.makeText(this, "Tempo: ${tempos[currentTempoIndex]}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Play a click sound and loop until stopped.
     * Uses MediaPlayer's setOnCompletionListener for continuous playback.
     */
    private fun playBeat() {
        // The click sound file must exist in res/raw/click.mp3
        val soundId = R.raw.click
        mediaPlayer = MediaPlayer.create(this, soundId)
        mediaPlayer?.start()

        // Loop the sound as long as isPlaying is true
        mediaPlayer?.setOnCompletionListener { mp ->
            if (isPlaying) mp.start()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Release MediaPlayer to avoid memory leaks
        mediaPlayer?.release()
        mediaPlayer = null
    }
}
