package com.mentor.myproject.ui.slideshow

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import com.mentor.myproject.MetronomeActivity
import com.mentor.myproject.R
import com.mentor.myproject.VirtualPianoActivity

class SlideshowFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_slideshow, container, false)

        // 返回按钮
        val btnBack = root.findViewById<Button>(R.id.btnBackSlideshow)
        btnBack.setOnClickListener { requireActivity().onBackPressed() }

        // 虚拟钢琴
        val btnVirtualPiano = root.findViewById<Button>(R.id.btnVirtualPiano)
        btnVirtualPiano.setOnClickListener {
            startActivity(Intent(requireContext(), VirtualPianoActivity::class.java))
        }

        // 节拍器
        val btnMetronome = root.findViewById<Button>(R.id.btnMetronome)
        btnMetronome.setOnClickListener {
            startActivity(Intent(requireContext(), MetronomeActivity::class.java))
        }

        // 指法教学
        val btnFingerTutorial = root.findViewById<Button>(R.id.btnFingerTutorial)
        btnFingerTutorial.setOnClickListener {
            val url = "https://www.youtube.com/results?search_query=piano+finger+tutorial"
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }

        // 退出应用
        val btnExit = root.findViewById<Button>(R.id.btnExit)
        btnExit.setOnClickListener {
            requireActivity().finishAffinity()
        }

        return root
    }
}
