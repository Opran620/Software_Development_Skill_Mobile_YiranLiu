package com.mentor.myproject

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mentor.myproject.databinding.ActivityPracticeMenuBinding

/**
 * PracticeMenuActivity
 * - Acts as a sub-menu for practice-related features
 * - Allows navigating to:
 *   1. Add Piece
 *   2. Start Practice
 *   3. View Statistics
 *   4. Recent Practice Records
 */
class PracticeMenuActivity : AppCompatActivity() {

    // ViewBinding instance to access layout views safely
    private lateinit var binding: ActivityPracticeMenuBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inflate layout using ViewBinding
        binding = ActivityPracticeMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)  // Must use binding.root

        // ----------------------
        // Back button
        // ----------------------
        // Returns to MainActivity
        binding.btnBack.setOnClickListener { finish() }

        // ----------------------
        // Navigate to AddPieceActivity
        // ----------------------
        binding.btnAddPiece.setOnClickListener {
            startActivity(Intent(this, AddPieceActivity::class.java))
        }

        // ----------------------
        // Navigate to PracticeActivity
        // ----------------------
        binding.btnStartPractice.setOnClickListener {
            startActivity(Intent(this, PracticeActivity::class.java))
        }

        // ----------------------
        // Navigate to StatsActivity
        // ----------------------
        binding.btnStats.setOnClickListener {
            startActivity(Intent(this, StatsActivity::class.java))
        }

        // ----------------------
        // Navigate to RecentActivity
        // ----------------------
        binding.btnRecent.setOnClickListener {
            startActivity(Intent(this, RecentActivity::class.java))
        }
    }
}
