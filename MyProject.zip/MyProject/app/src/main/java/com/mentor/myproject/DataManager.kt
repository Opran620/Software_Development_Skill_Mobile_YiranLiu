package com.mentor.myproject

import android.content.Context
import android.content.SharedPreferences

/**
 * Data class representing a practice record
 *
 * @param pieceName Name of the piano piece
 * @param timestamp Time when the practice occurred (milliseconds since epoch)
 * @param durationMinutes Duration of the practice in minutes
 */
data class PracticeRecord(val pieceName: String, val timestamp: Long, val durationMinutes: Int)

/**
 * Singleton object for managing persistent data:
 * - Last practiced piece
 * - Practice history
 *
 * Uses SharedPreferences for simple storage.
 */
object DataManager {

    // SharedPreferences file name
    private const val PREFS = "piano_trainer_prefs"

    // Key for storing last practiced piece
    private const val KEY_LAST = "last_piece"

    // Key for storing practice records
    private const val KEY_RECORDS = "records"

    // Helper function to get SharedPreferences instance
    private fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /**
     * Save the last practiced piece name
     */
    fun saveLastPiece(ctx: Context, name: String) {
        prefs(ctx).edit().putString(KEY_LAST, name).apply()
    }

    /**
     * Get the last practiced piece name
     */
    fun getLastPiece(ctx: Context): String? =
        prefs(ctx).getString(KEY_LAST, null)

    /**
     * Save a new practice record
     *
     * Records are stored as a single string in SharedPreferences in the format:
     * pieceName|timestamp|durationMinutes;
     */
    fun savePracticeRecord(ctx: Context, record: PracticeRecord) {
        val list = getPracticeRecords(ctx).toMutableList() // Load existing records

        // Create a new record entry as a string
        val entry = "${record.pieceName}|${record.timestamp}|${record.durationMinutes};"

        // Append to existing records string
        val newValue = buildString {
            append(prefs(ctx).getString(KEY_RECORDS, "") ?: "")
            append(entry)
        }

        // Save back to SharedPreferences
        prefs(ctx).edit().putString(KEY_RECORDS, newValue).apply()
    }

    /**
     * Get all practice records
     *
     * Parses the string stored in SharedPreferences into a list of PracticeRecord objects
     */
    fun getPracticeRecords(ctx: Context): List<PracticeRecord> {
        val raw = prefs(ctx).getString(KEY_RECORDS, "") ?: return emptyList()

        return raw.split(";") // Split each record by semicolon
            .filter { it.isNotBlank() } // Remove empty strings
            .mapNotNull {
                val parts = it.split("|")
                if (parts.size == 3) {
                    // Convert string parts to proper types
                    PracticeRecord(
                        parts[0],                    // pieceName
                        parts[1].toLongOrNull() ?: 0L, // timestamp
                        parts[2].toIntOrNull() ?: 0     // durationMinutes
                    )
                } else null
            }
    }
}
