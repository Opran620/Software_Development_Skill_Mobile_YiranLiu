package com.mentor.myproject

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mentor.myproject.databinding.ActivityMainBinding

/**
 * Main Activity of the app.
 * Shows buttons to navigate to different features:
 * - Practice menu
 * - Virtual piano
 * - Metronome
 * - Finger tutorial
 * - Exit app
 */
class MainActivity : AppCompatActivity() {

    // ViewBinding to access layout views safely without findViewById
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize ViewBinding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Navigate to Practice Menu
        binding.btnPractice.setOnClickListener {
            startActivity(Intent(this, PracticeMenuActivity::class.java))
        }

        // Navigate to Virtual Piano
        binding.btnVirtualPiano.setOnClickListener {
            startActivity(Intent(this, VirtualPianoActivity::class.java))
        }

        // Navigate to Metronome
        binding.btnMetronome.setOnClickListener {
            startActivity(Intent(this, MetronomeActivity::class.java))
        }

        // Navigate to Finger Tutorial
        binding.btnFingerTutorial.setOnClickListener {
            startActivity(Intent(this, FingerTutorialActivity::class.java))
        }

        // Exit the app
        binding.btnExit.setOnClickListener { finish() }
    }
}
