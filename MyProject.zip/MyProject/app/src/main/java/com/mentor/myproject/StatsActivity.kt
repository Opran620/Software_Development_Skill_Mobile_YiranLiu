package com.mentor.myproject

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mentor.myproject.databinding.ActivityStatsBinding

/**
 * StatsActivity
 * - Displays overall practice statistics
 * - Shows total practice time and number of distinct pieces practiced
 */
class StatsActivity : AppCompatActivity() {

    // ViewBinding instance to access layout views
    private lateinit var binding: ActivityStatsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inflate layout using ViewBinding
        binding = ActivityStatsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // ----------------------
        // Back button
        // ----------------------
        // Returns to the previous screen
        binding.btnBack.setOnClickListener { finish() }

        // ----------------------
        // Load practice records
        // ----------------------
        // Retrieve all practice records from DataManager
        // Sort by timestamp descending (latest first)
        val records = DataManager.getPracticeRecords(this)
            .sortedByDescending { it.timestamp }

        // ----------------------
        // Calculate statistics
        // ----------------------
        val totalMinutes = records.sumOf { it.durationMinutes } // Total practice time
        val uniquePieces = records.map { it.pieceName }.distinct().size // Number of distinct pieces

        // ----------------------
        // Update UI
        // ----------------------
        binding.tvTotalTime.text = "Total Practice Time: $totalMinutes minutes"
        binding.tvPiecesCount.text = "Pieces Practiced: $uniquePieces"
    }
}
