package com.mentor.myproject

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.mentor.myproject.databinding.ActivityRecentBinding
import java.text.SimpleDateFormat
import java.util.*

/**
 * RecentActivity
 * - Displays a list of recent practice sessions
 * - Clicking on a record opens the corresponding PracticeActivity
 */
class RecentActivity : AppCompatActivity() {

    // ViewBinding instance
    private lateinit var binding: ActivityRecentBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inflate layout using ViewBinding
        binding = ActivityRecentBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // ----------------------
        // Back button
        // ----------------------
        // Returns to the previous screen
        binding.btnBack.setOnClickListener { finish() }

        // ----------------------
        // Load recent practice records
        // ----------------------
        // DataManager stores PracticeRecord objects
        // Sort records by timestamp descending (latest first)
        val records = DataManager.getPracticeRecords(this)
            .sortedByDescending { it.timestamp }

        // ----------------------
        // Convert records into display strings for the ListView
        // ----------------------
        val displayList = records.map { record ->
            val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
                .format(Date(record.timestamp))
            "${record.pieceName} - $dateStr"
        }

        // ----------------------
        // Set up ListView adapter
        // ----------------------
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, displayList)
        binding.listViewRecent.adapter = adapter

        // ----------------------
        // Handle item clicks
        // ----------------------
        // When user clicks a record, open PracticeActivity with that piece
        binding.listViewRecent.setOnItemClickListener { _, _, position, _ ->
            val record = records[position]
            val intent = Intent(this, PracticeActivity::class.java)
            intent.putExtra("pieceName", record.pieceName)
            startActivity(intent)
        }
    }
}
