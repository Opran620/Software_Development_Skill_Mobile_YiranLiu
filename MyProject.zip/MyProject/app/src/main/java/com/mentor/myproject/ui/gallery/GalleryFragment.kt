package com.mentor.myproject.ui.gallery

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import com.mentor.myproject.PracticeActivity
import com.mentor.myproject.databinding.FragmentGalleryBinding

class GalleryFragment : Fragment() {

    private var _binding: FragmentGalleryBinding? = null
    private val binding get() = _binding!!

    private val pieces = listOf(
        "Happy Birthday",
        "Jingle Bells",
        "Scarborough Fair",
        "Twinkle Twinkle Little Star",
        "Castle in the Sky"
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentGalleryBinding.inflate(inflater, container, false)
        val root: View = binding.root

        // 设置标题
        binding.tvGalleryTitle.text = "Gallery"

        // 返回按钮
        binding.btnBackGallery.setOnClickListener { requireActivity().finish() }

        // ListView 适配器
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, pieces)
        binding.listViewGallery.adapter = adapter

        // 点击跳转到 PracticeActivity
        binding.listViewGallery.setOnItemClickListener { _, _, position, _ ->
            val pieceName = pieces[position]
            val intent = Intent(requireContext(), PracticeActivity::class.java)
            intent.putExtra("pieceName", pieceName)
            startActivity(intent)
        }

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
