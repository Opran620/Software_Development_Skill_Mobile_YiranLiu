package com.mentor.myproject

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mentor.myproject.databinding.ActivityFingerTutorialBinding

/**
 * Activity to show finger tutorial for piano.
 * Opens a YouTube video in the browser or YouTube app.
 */
class FingerTutorialActivity : AppCompatActivity() {

    // ViewBinding for accessing layout views
    private lateinit var binding: ActivityFingerTutorialBinding

    // URL of the tutorial video
    private val tutorialUrl = "https://www.youtube.com/watch?v=4SXQ_wlbWog"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize ViewBinding
        binding = ActivityFingerTutorialBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Back button: finish this activity
        binding.btnBack.setOnClickListener { finish() }

        // Open tutorial button: launch browser or YouTube app
        binding.btnOpenTutorial.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(tutorialUrl))
            startActivity(intent)
        }
    }
}
